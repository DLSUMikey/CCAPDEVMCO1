function goBackToLandingPage() {
    window.location.href = 'main.html';
  }