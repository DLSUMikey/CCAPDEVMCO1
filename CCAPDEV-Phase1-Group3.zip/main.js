function goToCalendar() {
    window.location.href = 'calendar.html';
  }